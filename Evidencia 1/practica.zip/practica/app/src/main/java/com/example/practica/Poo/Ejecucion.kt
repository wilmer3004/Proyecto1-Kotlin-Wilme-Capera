package com.example.practica.Poo

fun main(){
    val persona1:Persona = Persona()
}