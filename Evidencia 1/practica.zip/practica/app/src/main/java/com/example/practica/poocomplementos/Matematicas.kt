package com.example.practica.poocomplementos

object Matematicas {
    val PI = 3.1416

    fun aleatorio(min:Int,max:Int)=(Math.random()*(max+1-min)).toInt()

}