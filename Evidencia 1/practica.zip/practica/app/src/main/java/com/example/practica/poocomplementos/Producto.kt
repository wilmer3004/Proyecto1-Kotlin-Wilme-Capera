package com.example.practica.poocomplementos

data class Producto(var codigo:Int, var descripcion:String, var precio:Double)
