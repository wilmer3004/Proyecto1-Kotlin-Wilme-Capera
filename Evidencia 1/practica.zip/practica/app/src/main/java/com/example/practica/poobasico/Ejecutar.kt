package com.example.practica.poobasico


fun main(){

//    Constructor dentro de una clase (manual)

//    val persona1 : Persona = Persona()
//    persona1.inicializar(edad = 18, nombre = "Wilmer")
//    persona1.imprimir()
//    persona1.mayoriaEdad()
//    persona1.mayoriaEdad1()
//    val persona2 : Persona = Persona()
//    persona2.inicializar(edad = 17, nombre = "Andrea")
//    persona2.imprimir()
//    persona2.mayoriaEdad()
//    persona2.mayoriaEdad1()

//    Constructor con la palabra reservada constructor()

//    val personaConst=PersonaConstructor("Luis",42)
//    personaConst.imprimir()
//    personaConst.mayoriaEdad1()

//    Clase con parametros

    val personaParm=PersonaParametros("Fernanda",19)
    personaParm.imprimir()
    personaParm.mayoriaEdad1()



}