package com.example.practica.poocomplementos

enum class DatosCartas(val numCarta:Int) {
    DIAMANTE(1),
    TREBOL(2),
    CORAZON(3),
    PICA(4)
}